#Extreme Value Theory
rm(list=ls()) #Clear the memory
setwd("G:\\My Drive\\Asus\\Subjects_Preparation\\NuLearn\\AFRM\\Batch_12\\Sessions\\Session_11")
price=read.csv("Nifty.csv", header=T)
#Separating the price series from second column
nifty_p=price[,2]
n=length(nifty_p)
#Estimate Simple return
nifty=diff(nifty_p)/lag(nifty_p)
nifty=nifty[1:(n-1)]    #Use with older version of R
#nifty=nifty[2:n]       #Use with new version of R
nifty=-nifty        #Multiply Return with -1

library(fExtremes)
library(evir)
#Block Maxima Approach
#Block size 
n=20
# Fit the GEV model
gev_fit=gev(nifty,block=n)
gev_fit
param=gev_fit$par.ests
param

#Find VaR
VaR_gev_95=param[3]-(param[2]/param[1])*(1-(-n*log(1-0.05))^(-param[1]))
VaR_gev_95
VaR95_Rupee=VaR_gev_95*price[length(price[,2]),2]*100   #For 100 units
VaR95_Rupee

VaR_gev_99=param[3]-(param[2]/param[1])*(1-(-n*log(1-0.01))^(-param[1]))
VaR_gev_99
VaR99_Rupee=VaR_gev_99*price[length(price[,2]),2]*100   #For 100 units
VaR99_Rupee

VaR_gev_995=param[3]-(param[2]/param[1])*(1-(-n*log(1-0.005))^(-param[1]))
VaR_gev_995
VaR995_Rupee=VaR_gev_995*price[length(price[,2]),2]*100   #For 100 units
VaR995_Rupee

#Peak Over Threshold
#Mean Excess Function
mrlPlot(nifty)
pot_fit=pot(nifty,threshold=0.03)
pot_fit
# VaR and ES estimation under GPD
a=riskmeasures(pot_fit,c(0.95,0.99,0.995))   #estimate %age VaR and ES
a
VaR_95_Rupee=a[1,2]*price[length(price[,2]),2]*100
VaR_95_Rupee
VaR_99_Rupee=a[2,2]*price[length(price[,2]),2]*100
VaR_99_Rupee
VaR_995_Rupee=a[3,2]*price[length(price[,2]),2]*100
VaR_995_Rupee
write.csv(a,"EVT_RiskMeasures.csv")

beta=pot_fit$par.ests[[4]]   #Beta
psi=pot_fit$par.ests[[1]]  #Psi
u=pot_fit$threshold   #Threshold
n=pot_fit$span     #Number of observation
nu=pot_fit$n.exceed   #Number of exceedances
prob=0.95
VaR_95=u-(beta/psi)*(1-((n/nu)*(1-prob))^(-psi))
VaR_95
VaR_99=u-(beta/psi)*(1-((n/nu)*(1-0.99))^(-psi))
VaR_99
